import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ReviewDialogComponent } from '../review-dialog/review-dialog.component'; // 确保路径正确

@Component({
  selector: 'app-location-modal',
  templateUrl: './location-modal.component.html',
  styleUrls: ['./location-modal.component.css']
})
export class LocationModalComponent {
  reviews = [
    { userId: '1', nickname: 'Alice', rating: 5, comment: 'Great product!' },
    { userId: '2', nickname: 'Bob', rating: 4, comment: 'Good, but could be better.' },
    { userId: '3', nickname: 'Charlie', rating: 3, comment: 'Average.' }
  ];

  constructor(
    public dialogRef: MatDialogRef<LocationModalComponent>,
    private router: Router,
    private dialog: MatDialog, // 注入MatDialog服务
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  save() {
    // Implement save functionality
    console.log('Location saved:', this.data.title);
  }

  close(): void {
    this.dialogRef.close();
  }

  openReviewDialog() {
    const userId = localStorage.getItem('userId');
    if (!userId) {
      this.dialogRef.close();
      // 用户未登录，跳转到登录页面
      this.router.navigate(['/login']);
    } else {
      // 用户已登录，打开评论对话框
      const reviewDialogRef = this.dialog.open(ReviewDialogComponent, {
        width: '800px', // 调整弹窗宽度
        data: { reviews: this.reviews }, // 传递评论数据
        panelClass: 'custom-dialog-container', // 添加自定义样式类
        hasBackdrop: true // 确保有背景遮罩
      });
    }
  }
}
