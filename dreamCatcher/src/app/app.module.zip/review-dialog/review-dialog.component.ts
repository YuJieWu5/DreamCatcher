import {Component, Inject} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-review-dialog',
  templateUrl: './review-dialog.component.html',
  styleUrls: ['./review-dialog.component.css']
})
export class ReviewDialogComponent {
  reviews: any[];

  constructor(
    public dialogRef: MatDialogRef<ReviewDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.reviews = data.reviews || []; // 确保有默认值
  }

  onAddReview(): void {
    // 实现添加评论的逻辑
    this.dialogRef.close();
  }

  onClose(): void {
    this.dialogRef.close();
  }
}
